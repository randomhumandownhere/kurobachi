(function(){"use strict";const n=document.getElementById("extension-root");n&&(console.log("existing instance found, removing"),n.remove())})();
